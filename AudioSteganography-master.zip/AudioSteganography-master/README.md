AudioSteganography
==================

Licence: Creative Commmong Licence

Author: Saprative Jana

Audio Steganography is the method of hiding data within a audio file. 

Installation
============
1. Install python3
2. Install pip
3. Run in shell: sudo pip install numpy
4. Run in shell: python main.py
5. Result: opera_new.wav 

